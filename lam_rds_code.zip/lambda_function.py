import mysql.connector
import ujson as json
import csv
import base64
import json
import gzip
import shutil
from mysql.connector import Error
# not format display
def compress_data(data):
    json_data = json.dumps(data).encode('utf-8')
    compressed_data = gzip.compress(json_data)
    base64_data = base64.b64encode(compressed_data)  # base64 encode the data
    return base64_data.decode('utf-8')
#format display with indent=2
# def compress_data(data):
#     json_data = json.dumps(data, indent=2).encode('utf-8')  # add indent parameter
#     compressed_data = gzip.compress(json_data)
#     base64_data = base64.b64encode(compressed_data)
#     return base64_data.decode('utf-8')
def compress_data_(data):
    json_data = json.dumps(data).encode('utf-8')
    compressed_data = gzip.compress(json_data)
    base64_data = base64.b64encode(compressed_data)  # base64 encode the data

    # Get the current date for filename
    date = datetime.datetime.now().strftime('%Y%m%d')
    csv_file = f'/tmp/data_tram_{date}.csv'
    compressed_file = f'/tmp/data_tram_{date}.csv.gz' 

    with open(csv_file, 'w', newline='') as csv_obj:
        csv_writer = csv.writer(csv_obj)
        header = ['id', 'TimeStamp', 'Temperature', 'Humidity', 'Cps','uSv','Counts','LocalTime']
        csv_writer.writerow(header)
        for item in json_data:
            csv_writer.writerow(item.values())
    
    with open(csv_file, 'rb') as f_in:
        with gzip.open(compressed_file, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)

    return base64_data.decode('utf-8')
def lambda_handler(event, context):

# timestamp,temperature,humidity,cps,uSv,counts
    print(event)
    
    # date = getDate()
    # if(date>=(prevdate+7))
    #     CREATE DROP data.data ( );
    #     create database data;
    #     CREATE IF NOT TABLE data.data (
    #         id INT AUTO_INCREMENT PRIMARY KEY,
    #         value INT,
    #         epochTime INT,
    #         Temperature INT,
    #         Humidity INT
    #     );
    #     prevdate = date
         
    config = {
        'user': 'admin',
        'password': 'Admin20244',
        'host': 'data.cnmweia6u3ra.ap-southeast-1.rds.amazonaws.com',
        'database': 'data',
    }
    
    try:

        conn = mysql.connector.connect(**config)
        if conn.is_connected():
            cursor = conn.cursor()
            http_method = event.get('httpMethod')
            resource = event.get('resource')
            # if 'timestamp'and 'temperature'and'humidity'and'cps'and'uSv' and 'LocalTime' in event:
            #     # print('yes')
            #     TimeStamp = str(event['timestamp'])
            #     Temperature = str(event["temperature"])
            #     Humidity = str(event["humidity"])
            #     Cps=str(event["cps"])
            #     uSv=str(event["uSv"])
            #     Counts=str(event["counts"])
            #     LocalTime=event['LocalTime']
            #     # print(Temperature)
            #     insert_query = "INSERT INTO data.datanew (TimeStamp,Temperature,Humidity,Cps,uSv,Counts,DateTime) VALUES (%s, %s,%s,%s,%s,%s,%s)"
            #     insert_data = (TimeStamp,Temperature,Humidity,Cps,uSv,Counts,LocalTime)
            #     cursor.execute(insert_query, insert_data)
            #     conn.commit()   
            # else:
            #     print("no")
            if http_method =="GET" and resource =="/lam_rds":
                
                cursor.execute("SELECT * FROM data.datanew")
                data = cursor.fetchall()
                json_data = [{
                    'id': row[0],
                    'TimeStamp': row[1],
                    'Temperature': row[2],
                    'Humidity': row[3],
                    'Cps': row[4],
                    'uSv': row[5],
                    'Counts': row[6],
                    'LocalTime': row[7]
                } for row in data]
                json_data.append(json_row)
                compressed_json_data = compress_data(json_data)
                return {
                'statusCode': 200,
                'headers': {
                    'Content-Encoding': 'gzip',
                    # 'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept'
                },
                # 'body': json.dumps(json_data, indent=2) 
                'body':compressed_json_data,
                'isBase64Encoded': True
                }
            elif http_method =="GET" and resource =="/lam_rds/{id}":
                id = event['pathParameters']['id']
         
                cursor.execute(f"SELECT * FROM data.datanew WHERE id = {id}")
                #value,epochTime,Temperature,Humidity
                data = cursor.fetchall()
                json_data = []
                for row in data:
                    json_row = {
                        'id': row[0],  # Assuming id is the first column
                        'TimeStamp': row[1],
                        'Temperature': row[2],
                        'Humidity': row[3],
                        'Cps':row[4],
                        'uSv':row[5],
                        'Counts':row[6],
                        'LocalTime':row[7]
                    }
                    json_data.append(json_row)
    
                return {
                    'statusCode': 200,
                    'headers': {
                        "Access-Control-Allow-Origin": "*",  # or specify your allowed origin
                        "Access-Control-Allow-Headers": "Origin, X-Requested-With, Content-Type, Accept"
                    },
                    'body': json.dumps(json_data, indent=2)  # Corrected syntax here
                }
            elif http_method =="GET" and resource =="/lam_rds/csvfilef": #address of api
                
                cursor.execute("SELECT * FROM data.datanew")
                data = cursor.fetchall()
                json_data = []
                for row in data:
                    json_row = {
                        'id': row[0],  # Assuming id is the first column
                        'TimeStamp': row[1],
                        'Temperature': row[2],
                        'Humidity': row[3],
                        'Cps':row[4],
                        'uSv':row[5],
                        'Counts':row[6],
                        'LocalTime':row[7]
                    }
                    json_data.append(json_row)
                # tao csv file va respone API download file csv
                csv_file = '/tmp/data_tram.csv'
                compressed_file = '/tmp/data_tram.csv.gz' 
                with open(csv_file, 'w', newline='') as csv_obj:
                    csv_writer = csv.writer(csv_obj)
                    header = ['id', 'TimeStamp', 'Temperature', 'Humidity', 'Cps','uSv','Counts','LocalTime']
                    csv_writer.writerow(header)
                    for item in json_data:
                        csv_writer.writerow(item.values())
                
                headers = {
                    'Content-Disposition': 'attachment; filename="data_tram.csv.gz"',
                    'Content-Type': 'text/csv',
                }
                with open(csv_file, 'rb') as f_in:
                    with gzip.open(compressed_file, 'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out)
                with open(compressed_file, 'rb') as file:
                    csv_content = file.read()
                # with open(csv_file, 'rb') as file:
                #     csv_content = file.read()
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': base64.b64encode(csv_content).decode('utf-8'),
                    'isBase64Encoded': True  # Indicate that the body is base64 encoded
                }
                # return {
                #     'statusCode': 200,
                #     'headers': headers,
                #     # 'body':csv_content,
                #     # 'isBase64Encoded': False
                #     'body': base64.b64encode(csv_content).decode('utf-8'),
                #     'isBase64Encoded': True  # Indicate that the body is base64 encoded
                # }
            elif http_method =="GET" and resource =="/lam_rds/csvfile": #address of api
                
                cursor.execute("SELECT * FROM data.datanew")
                data = cursor.fetchall()
                json_data = []
                for row in data:
                    json_row = {
                        'id': row[0],  # Assuming id is the first column
                        'TimeStamp': row[1],
                        'Temperature': row[2],
                        'Humidity': row[3],
                        'Cps':row[4],
                        'uSv':row[5],
                        'Counts':row[6],
                        'LocalTime':row[7]
                    }
                    json_data.append(json_row)
                # tao csv file va respone API download file csv
                csv_file = '/tmp/data_tram.csv'
                with open(csv_file, 'w', newline='') as csv_obj:
                    csv_writer = csv.writer(csv_obj)
                    header = ['id', 'TimeStamp', 'Temperature', 'Humidity', 'Cps','uSv','Counts','LocalTime']
                    csv_writer.writerow(header)
                    for item in json_data:
                        csv_writer.writerow(item.values())
                
                headers = {
                    'Content-Disposition': 'attachment; filename="data_tram.csv"',
                    'Content-Type': 'text/csv',
                }
                with open(csv_file, 'rb') as file:
                    csv_content = file.read()
                return {
                    'statusCode': 200,
                    'headers': headers,
                    # 'body':csv_content,
                    # 'isBase64Encoded': False
                    'body': base64.b64encode(csv_content).decode('utf-8'),
                    'isBase64Encoded': True  # Indicate that the body is base64 encoded
                }
            elif http_method =="GET" and resource =="/lam_rds/lastest":
                
                cursor.execute(f"SELECT * FROM data.datanew ORDER BY id DESC LIMIT 1")
                data = cursor.fetchall()
                json_data = []
                for row in data:
                    json_row = {
                        'id': row[0],  # Assuming id is the first column
                        'TimeStamp': row[1],
                        'Temperature': row[2],
                        'Humidity': row[3],
                        'Cps':row[4],
                        'uSv':row[5],
                        'Counts':row[6],
                        'LocalTime':row[7]
                    }
                    json_data.append(json_row)
                return {
                'statusCode': 200,
                'body': json.dumps(json_data, indent=2) 
                }
            
            # elif http_method =="GET" and resource =="/lam_rds/lastest20":
                
            #     cursor.execute(f"SELECT * FROM data.datanew ORDER BY id DESC LIMIT 20")
            #     data = cursor.fetchall()
            #     json_data = []
            #     for row in data:
            #         json_row = {
            #             'id': row[0],  # Assuming id is the first column
            #             'TimeStamp': row[1],
            #             'Temperature': row[2],
            #             'Humidity': row[3],
            #             'Cps':row[4],
            #             'uSv':row[5],
            #             'Counts':row[6],
            #             'LocalTime':row[7]
            #         }
            #         json_data.append(json_row)
            #     return {
            #     'statusCode': 200,
            #     'body': json.dumps(json_data, indent=2) 
            #     }
            
            
 
            if 'timestamp'and 'temperature'and'humidity'and'cps'and'uSv' and 'LocalTime' in event:
                # print('yes')
                TimeStamp = str(event['timestamp'])
                Temperature = str(event["temperature"])
                Humidity = str(event["humidity"])
                Cps=str(event["cps"])
                uSv=str(event["uSv"])
                Counts=str(event["counts"])
                LocalTime=event['LocalTime']
                # print(Temperature)
                insert_query = "INSERT INTO data.datanew (TimeStamp,Temperature,Humidity,Cps,uSv,Counts,DateTime) VALUES (%s, %s,%s,%s,%s,%s,%s)"
                insert_data = (TimeStamp,Temperature,Humidity,Cps,uSv,Counts,LocalTime)
                cursor.execute(insert_query, insert_data)
                conn.commit()   
            else:
                print("no")
                

            # insert_query = "INSERT INTO data.datanew (TimeStamp,Temperature,Humidity,Cps,uSv,Counts) VALUES (%s, %s,%s,%s,%s,%s)"
            # insert_data = (TimeStamp,Temperature,Humidity,Cps,uSv,Counts)
            # cursor.execute(insert_query, insert_data)
            # conn.commit()             
         
            cursor.close()
     
    except mysql.connector.Error as e:
        print("Error connectd")
        print(e)
    finally:
        if conn.is_connected():
            conn.close()

# def lambda_handler(event, context):
#     try:
#         connection = mysql.connector.connect(
#             host='data.cnmweia6u3ra.ap-southeast-1.rds.amazonaws.com',
#             user='admin',
#             password='Admin20244',
#             database='data'
#         )

#         if connection.is_connected():
#             cursor = connection.cursor()
#             sql_query = "SELECT SUM(data_length + index_length) AS total_size FROM information_schema.tables;"
#             cursor.execute(sql_query)
#             result = cursor.fetchone()
#             total_size = result[0]
#             total_size_mb = total_size / (1024 * 1024)  
#             total_size_kb = total_size / 1024  
#             # Trả về kết quả
#             return {
#                 'statusCode': 200,
#                 'body': {
#                         'total_size_mb': total_size_mb,
#                         'total_size_kb': total_size_kb
#                 }
#             }
#     except Error as e:
#         # Xử lý lỗi nếu có
#         return {
#             'statusCode': 500,
#             'body': {
#                 'error': str(e)
#             }
#         }
#     finally:
#         # Đóng kết nối sau khi thực hiện xong
#         if connection.is_connected():
#             cursor.close()
#             connection.close()